﻿USE [wbsn-data-security];

UPDATE PA_CONFIG_PROPERTIES SET VALUE = 'true' WHERE NAME = 'notifyOriginalSenderOnRelease';

